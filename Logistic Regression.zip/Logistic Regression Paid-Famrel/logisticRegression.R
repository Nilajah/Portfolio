training.data.raw <- read.csv('student-mat.csv',header=T,na.strings=c(""))
sapply(training.data.raw,function(x) sum(is.na(x)))
sink("RegressionOutput.txt", append=FALSE, split=TRUE);
library(Amelia)
missmap(training.data.raw, main = "Missing values vs observed")
mydata1 <- subset(training.data.raw,select=c(18,24,34))



model1 <- glm(G4 ~.,family=binomial(link='logit'),data=mydata)
summary(model1)
anova(model1, test="Chisq")


# mydata2 <- subset(training.data.raw,select=c("sex", "age", "address" , "Medu", "Fedu", "guardian", "studytime", "schoolsup", 
#                                              "famsup", "paid", "famrel", "Dalc", "higher", "health", "absences"))



model2 <- glm(G4 ~ sex + age + address + Medu + Fedu + guardian + studytime + schoolsup + 
                famsup + paid + famrel + Dalc + higher + health + absences,family=binomial(link='logit'),data=training.data.raw)
summary(model2)
anova(model2, test="Chisq")


