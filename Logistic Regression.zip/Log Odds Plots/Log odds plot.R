library(tidyverse)
library(broom)
theme_set(theme_classic())
# Load the data
mydata = read.csv("student-mat4.csv", header = TRUE)
pdf("logplots2.pdf")
# Fit the logistic regression model
model <- glm(G4 ~., data = mydata, 
             family = binomial)
# Predict the probability (p) of diabete positivity
probabilities <- predict(model, type = "response")
predicted.classes <- ifelse(probabilities > 0.5, 1, 0)
head(predicted.classes)
# Select only numeric predictors
mydata <- mydata %>%
  dplyr::select_if(is.numeric) 
predictors <- colnames(mydata)
# Bind the logit and tidying the data for plot
mydata <- mydata %>%
  mutate(logit = log(probabilities/(1-probabilities))) %>%
  gather(key = "predictors", value = "predictor.value", -logit)
ggplot(mydata, aes(logit, predictor.value))+
  geom_point(size = 0.5, alpha = 0.5) +
  geom_smooth(method = "loess") + 
  theme_bw() + 
  facet_wrap(~predictors, scales = "free_y")